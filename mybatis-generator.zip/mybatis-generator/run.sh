#!/bin/bash - 
export LANG=zh_CN.UTF-8
#===============================================================================
#
#          FILE: run.sh
# 
#   DESCRIPTION: 
# 
#        Author: 张翼
#         Email: changyu.zy@alibaba-inc.com
#       Company: Alibaba
#       Created: 2016/03/22 18:10
#===============================================================================

set -o nounset                              # Treat unset variables as an error
java -jar mybatis-generator-core-1.3.2.jar -configfile ./generatorConfig.xml -overwrite

